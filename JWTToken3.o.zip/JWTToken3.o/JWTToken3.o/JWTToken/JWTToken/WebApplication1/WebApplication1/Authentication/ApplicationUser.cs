﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace WebApplication1.Controllers.Authentication
{
    public class ApplicationUser:IdentityUser
    {
    }
}
