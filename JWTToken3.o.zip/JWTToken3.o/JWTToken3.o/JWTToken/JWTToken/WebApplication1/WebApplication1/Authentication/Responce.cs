﻿namespace WebApplication1.Authentication
{
    public class Responce
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
